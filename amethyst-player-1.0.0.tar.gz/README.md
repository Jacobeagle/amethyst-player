![picture](https://i.ibb.co/qDsmMMS/youtube-logo-png-transparent-image-5.png)

Unofficial Youtube application, Open source and multi-platform for all platforms to use.

Enjoy all your Youtube content just like on the web version all wrapped up into a desktop application!

&nbsp;&nbsp;&nbsp;&nbsp;

![picture](https://i.ibb.co/28FH9Cn/yt-screenshot1.png)

![picture](https://i.ibb.co/2hYrRHN/yt-screenshot2.png)

Even manage and run your streams conveniently from the Youtube application.

![picture](https://i.ibb.co/pfd67Qy/yt-screenshot3.png)

 &nbsp;&nbsp;&nbsp;&nbsp;

  You can install Youtube from the AUR for Arch/Manjaro distros.
 [Click Here](https://aur.archlinux.org/packages/youtube/)

 ### Download For All platforms (Linux, Mac OS and Windows)
  
  [Click to get the latest release](https://gitlab.com/youtube-desktop/application/-/releases)

 ### Author
  * Corey Bruce
